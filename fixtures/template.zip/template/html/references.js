// Generated from references.bib by tools/tex2html -- do not edit by hand.
window.BIBTEX = String.raw`% Placeholder entries -- replace with your own references.

@article{placeholder_article,
  author  = {Surname, A. and Surname, A.},
  title   = {[Article Title]},
  journal = {[Journal Name]},
  year    = {[Year]},
  volume  = {[Volume]},
  pages   = {[Pages]},
  doi     = {[DOI]}
}

@inproceedings{placeholder_conference,
  author    = {Surname, A.},
  title     = {[Paper Title]},
  booktitle = {[Proceedings / Conference Name]},
  year      = {[Year]},
  pages     = {[Pages]}
}

@book{placeholder_book,
  author    = {Surname, A.},
  title     = {[Book Title]},
  publisher = {[Publisher]},
  year      = {[Year]}
}

@phdthesis{placeholder_thesis,
  author = {Surname, A.},
  title  = {[Thesis Title]},
  school = {[Institute]},
  year   = {[Year]}
}
`;
